// ════════════════════════════════════════════════════════════
// FILE: bloc/quote_bloc.dart
// ════════════════════════════════════════════════════════════
// WHAT YOU LEARN:
//  1. Events — what the UI sends INTO the BLoC
//  2. States — what the BLoC sends OUT to the UI
//  3. 3-state pattern — Loading, Loaded, Error (every real app)
//  4. on<Event>() — register handler for each event type
//  5. emit() — push new state to all BlocBuilder listeners
//  6. async handler — await API call inside BLoC handler
//  7. PRIVATE service (_service) — BLoC owns it, UI never touches it
//  8. Equatable on states — skip rebuild if state didn't change
// ════════════════════════════════════════════════════════════

import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../model/quote_model.dart';
import '../service/quote_service.dart';

// ════════════════════════════════════════════════════════════
// EVENTS
// Events = things that happen in the UI
// UI sends events IN to the BLoC using bloc.add(event)
// ════════════════════════════════════════════════════════════

// Abstract base — cannot create QuoteEvent() directly
// Forces use of concrete subclasses below
abstract class QuoteEvent extends Equatable {
  const QuoteEvent();
  @override
  List<Object?> get props => [];
}

// User tapped "Get Quote" button or screen first loaded
class QuoteFetchRequested extends QuoteEvent {
  const QuoteFetchRequested();
}

// User tapped "Save to Favourites" button
class QuoteSaved extends QuoteEvent {
  final Quote quote; // PUBLIC — carries the quote to save
  const QuoteSaved(this.quote);
  @override
  List<Object?> get props => [quote];
}

// ════════════════════════════════════════════════════════════
// STATES
// States = what the BLoC sends OUT to the UI
// UI rebuilds based on which state it receives
// ════════════════════════════════════════════════════════════

// Abstract base for all states
abstract class QuoteState extends Equatable {
  const QuoteState();
  @override
  List<Object?> get props => [];
}

// App just opened — nothing fetched yet
class QuoteInitial extends QuoteState {
  const QuoteInitial();
}

// API call in progress — show spinner
class QuoteLoading extends QuoteState {
  const QuoteLoading();
}

// API call succeeded — show the quote
class QuoteLoaded extends QuoteState {
  // PUBLIC field — UI reads this to display the quote
  final Quote quote;

  // PUBLIC field — list of saved quotes
  final List<Quote> savedQuotes;

  const QuoteLoaded({
    required this.quote,
    this.savedQuotes = const [],
  });

  // copyWith — immutable update pattern
  // Create new state with only changed fields
  QuoteLoaded copyWith({
    Quote? quote,
    List<Quote>? savedQuotes,
  }) {
    return QuoteLoaded(
      quote:       quote       ?? this.quote,
      savedQuotes: savedQuotes ?? this.savedQuotes,
    );
  }

  @override
  List<Object?> get props => [quote, savedQuotes];
}

// API call failed — show error message + retry button
class QuoteError extends QuoteState {
  // PUBLIC field — UI displays this message
  final String message;
  const QuoteError(this.message);
  @override
  List<Object?> get props => [message];
}

// ════════════════════════════════════════════════════════════
// BLOC
// Bloc<EventType, StateType>
// Receives QuoteEvent → processes → emits QuoteState
// ════════════════════════════════════════════════════════════

class QuoteBloc extends Bloc<QuoteEvent, QuoteState> {
  // PRIVATE service instance — only QuoteBloc calls API
  // UI never touches QuoteService directly
  final QuoteService _service;

  // Constructor — inject service (default = real service)
  // Starting state = QuoteInitial (nothing loaded yet)
  QuoteBloc({QuoteService? service})
      : _service = service ?? QuoteService(),
        super(const QuoteInitial()) {
    // Register handlers — one per event type
    on<QuoteFetchRequested>(_onFetch);
    on<QuoteSaved>(_onSave);
  }

  // ── HANDLER 1: Fetch a quote ────────────────────────────
  // Called when UI sends QuoteFetchRequested event
  // Future<void> because we use await inside
  Future<void> _onFetch(
    QuoteFetchRequested event,
    Emitter<QuoteState> emit,
  ) async {
    // Step 1: tell UI we are loading → shows spinner
    emit(const QuoteLoading());

    try {
      // Step 2: await API call — pauses here until response
      final quote = await _service.fetchRandomQuote();

      // Step 3: success → send quote to UI
      // Preserve existing savedQuotes if we already had some
      final currentSaved = state is QuoteLoaded
          ? (state as QuoteLoaded).savedQuotes
          : <Quote>[];

      emit(QuoteLoaded(quote: quote, savedQuotes: currentSaved));

    } catch (e) {
      // Step 4: something went wrong → send error to UI
      emit(QuoteError(e.toString().replaceAll('Exception: ', '')));
    }
  }

  // ── HANDLER 2: Save a quote ─────────────────────────────
  // Called when user taps the save/bookmark button
  void _onSave(
    QuoteSaved event,
    Emitter<QuoteState> emit,
  ) {
    // Only act if we are in loaded state
    if (state is! QuoteLoaded) return;
    final current = state as QuoteLoaded;

    // Check if already saved — avoid duplicates
    final alreadySaved = current.savedQuotes.contains(event.quote);
    if (alreadySaved) return;

    // Create new list with the new quote added
    // Never mutate the existing list — spread into a new one
    final updatedSaved = [...current.savedQuotes, event.quote];

    // copyWith — keep current quote, just update saved list
    emit(current.copyWith(savedQuotes: updatedSaved));
  }
}
