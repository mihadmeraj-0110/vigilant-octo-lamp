// ════════════════════════════════════════════════════════════
// FILE: model/quote_model.dart
// ════════════════════════════════════════════════════════════
// WHAT YOU LEARN:
//  1. Model class — represents one piece of data from API
//  2. PRIVATE fields (_text, _author) — underscore = private
//  3. PUBLIC getters — controlled read access to private fields
//  4. factory fromJson — parse API JSON into a Dart object
//  5. toString() — useful when printing/debugging
//  6. Equatable — value equality comparison
// ════════════════════════════════════════════════════════════

import 'package:equatable/equatable.dart';

class Quote extends Equatable {
  // PRIVATE fields — nobody outside this file sets these directly
  final String _text;
  final String _author;

  // Constructor — private fields assigned via initialiser list
  const Quote._({
    required String text,
    required String author,
  })  : _text = text,
        _author = author;

  // ── factory fromJson ──────────────────────────────────────
  // Called like: Quote.fromJson(jsonMap)
  // API response looks like:
  // [{ "q": "Be yourself", "a": "Oscar Wilde", "h": "<html>" }]
  // We parse the first item in the list
  factory Quote.fromJson(Map<String, dynamic> json) {
    return Quote._(
      // json['q'] = the quote text field from API
      // as String — cast dynamic to String safely
      // ?? '' — fallback to empty string if null
      text:   (json['q'] as String?)   ?? 'No quote available',
      author: (json['a'] as String?)   ?? 'Unknown',
    );
  }

  // PUBLIC getters — UI reads these, cannot set from outside
  String get text   => _text;
  String get author => _author;

  // toString — what prints when you do print(quote)
  @override
  String toString() => '"$_text" — $_author';

  // props — Equatable uses this to compare two Quote objects
  // Two quotes are equal if both text AND author are the same
  @override
  List<Object?> get props => [_text, _author];
}
