// ════════════════════════════════════════════════════════════
// FILE: screen/quote_screen.dart
// ════════════════════════════════════════════════════════════
// WHAT YOU LEARN:
//  1. BlocBuilder — rebuild UI when state changes
//  2. BlocListener — side effects (snackbar) on state change
//  3. BlocConsumer — both together
//  4. Switching UI based on state type using 'is' keyword
//  5. context.read<T>().add(event) — dispatch event from UI
//  6. Pull to refresh — RefreshIndicator
//  7. AnimatedSwitcher — smooth transition between states
//  8. Extracting widgets — keep build() clean and readable
// ════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/quote_bloc.dart';

class QuoteScreen extends StatelessWidget {
  // PUBLIC key — passed from outside (main.dart passes none, uses default)
  const QuoteScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1A1A2E),

      appBar: AppBar(
        backgroundColor: const Color(0xFF16213E),
        title: const Text(
          '💬 Quote of the Day',
          // const Text — this Text never rebuilds even when
          // parent rebuilds. Free performance win.
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        // BlocBuilder just for the saved count badge
        // Only this small widget rebuilds when savedQuotes changes
        // NOT the entire AppBar — that is the efficiency of targeted BlocBuilder
        actions: [
          BlocBuilder<QuoteBloc, QuoteState>(
            // buildWhen — only rebuild when saved quotes count changes
            // Skip ALL other state changes for this widget
            buildWhen: (previous, current) {
              final prevCount = previous is QuoteLoaded
                  ? previous.savedQuotes.length
                  : 0;
              final currCount = current is QuoteLoaded
                  ? current.savedQuotes.length
                  : 0;
              return prevCount != currCount;
            },
            builder: (context, state) {
              final count = state is QuoteLoaded
                  ? state.savedQuotes.length
                  : 0;
              return IconButton(
                icon: Badge(
                  label: Text('$count'),
                  isLabelVisible: count > 0,
                  child: const Icon(Icons.bookmark, color: Colors.white),
                ),
                onPressed: () {
                  if (state is QuoteLoaded && state.savedQuotes.isNotEmpty) {
                    _showSavedQuotes(context, state.savedQuotes);
                  }
                },
              );
            },
          ),
        ],
      ),

      body: BlocConsumer<QuoteBloc, QuoteState>(
        // listenWhen — only run listener when a quote is saved
        // Specifically: savedQuotes count went UP
        listenWhen: (previous, current) {
          if (previous is QuoteLoaded && current is QuoteLoaded) {
            return current.savedQuotes.length > previous.savedQuotes.length;
          }
          return false;
        },

        // listener — show snackbar when quote saved
        // Does NOT rebuild UI — side effect only
        listener: (context, state) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('✅ Quote saved!'),
              backgroundColor: Colors.green,
              duration: Duration(seconds: 1),
            ),
          );
        },

        // builder — rebuild UI based on current state
        builder: (context, state) {
          // AnimatedSwitcher — smooth crossfade when state changes
          return AnimatedSwitcher(
            duration: const Duration(milliseconds: 400),
            child: _buildBody(context, state),
          );
        },
      ),

      // FAB — get a new quote
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          // context.read — get BLoC, dispatch event, no rebuild
          context.read<QuoteBloc>().add(const QuoteFetchRequested());
        },
        icon: const Icon(Icons.refresh),
        label: const Text('New Quote'),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
    );
  }

  // PRIVATE method — builds different UI based on state type
  // Extracted to keep build() clean and readable
  Widget _buildBody(BuildContext context, QuoteState state) {
    // 'is' keyword — runtime type check
    // Checks which concrete state we are in

    if (state is QuoteInitial) {
      return const _CentreMessage(
        key: ValueKey('initial'),
        icon: Icons.format_quote,
        message: 'Tap the button to get a quote!',
      );
    }

    if (state is QuoteLoading) {
      return const _LoadingView(key: ValueKey('loading'));
    }

    if (state is QuoteError) {
      return _ErrorView(
        key: const ValueKey('error'),
        // state.message — PUBLIC field from QuoteError
        message: state.message,
        onRetry: () {
          context.read<QuoteBloc>().add(const QuoteFetchRequested());
        },
      );
    }

    if (state is QuoteLoaded) {
      return _QuoteView(
        key: ValueKey(state.quote.text), // key changes = AnimatedSwitcher animates
        // state.quote — PUBLIC field from QuoteLoaded
        quote: state.quote,
        onSave: () {
          context.read<QuoteBloc>().add(QuoteSaved(state.quote));
        },
        isSaved: state.savedQuotes.contains(state.quote),
      );
    }

    return const SizedBox();
  }

  // Show bottom sheet with saved quotes list
  void _showSavedQuotes(BuildContext context, List savedQuotes) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF16213E),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Saved Quotes',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                itemCount: savedQuotes.length,
                itemBuilder: (_, i) => Card(
                  color: const Color(0xFF0F3460),
                  margin: const EdgeInsets.only(bottom: 8),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '"${savedQuotes[i].text}"',
                          style: const TextStyle(color: Colors.white, fontSize: 13),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          '— ${savedQuotes[i].author}',
                          style: TextStyle(color: Colors.purple.shade200, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── PRIVATE WIDGETS ──────────────────────────────────────────
// These widgets are PRIVATE (underscore prefix)
// They are only used inside this file
// Extracted to keep build() clean — good practice!

// Loading state widget
class _LoadingView extends StatelessWidget {
  const _LoadingView({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(color: Colors.deepPurple),
          SizedBox(height: 16),
          Text(
            'Getting your quote...',
            style: TextStyle(color: Colors.white70),
          ),
        ],
      ),
    );
  }
}

// Error state widget
class _ErrorView extends StatelessWidget {
  // PUBLIC fields — passed from parent
  final String message;
  final VoidCallback onRetry;

  const _ErrorView({
    super.key,
    required this.message,
    required this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.wifi_off, color: Colors.red, size: 64),
            const SizedBox(height: 16),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white70, fontSize: 14),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh),
              label: const Text('Try Again'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple,
                foregroundColor: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Loaded state widget — the main quote card
class _QuoteView extends StatelessWidget {
  final dynamic quote;    // Quote model
  final VoidCallback onSave;
  final bool isSaved;

  const _QuoteView({
    super.key,
    required this.quote,
    required this.onSave,
    required this.isSaved,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Quote mark decoration
          const Icon(Icons.format_quote, color: Colors.deepPurple, size: 48),
          const SizedBox(height: 16),

          // Quote card
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: const Color(0xFF16213E),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.deepPurple.shade700, width: 1),
              boxShadow: [
                BoxShadow(
                  color: Colors.deepPurple.withOpacity(0.3),
                  blurRadius: 20,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Column(
              children: [
                // quote.text — PUBLIC getter from Quote model
                Text(
                  '"${quote.text}"',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontStyle: FontStyle.italic,
                    height: 1.6,
                  ),
                ),
                const SizedBox(height: 20),
                const Divider(color: Colors.deepPurple),
                const SizedBox(height: 12),
                // quote.author — PUBLIC getter from Quote model
                Text(
                  '— ${quote.author}',
                  style: TextStyle(
                    color: Colors.purple.shade300,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 24),

          // Save button
          ElevatedButton.icon(
            onPressed: isSaved ? null : onSave,
            icon: Icon(isSaved ? Icons.bookmark : Icons.bookmark_border),
            label: Text(isSaved ? 'Saved!' : 'Save Quote'),
            style: ElevatedButton.styleFrom(
              backgroundColor: isSaved ? Colors.grey : Colors.deepPurple,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
            ),
          ),
        ],
      ),
    );
  }
}

// Generic centre message widget — initial state
class _CentreMessage extends StatelessWidget {
  final IconData icon;
  final String message;

  const _CentreMessage({
    super.key,
    required this.icon,
    required this.message,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: Colors.deepPurple, size: 64),
          const SizedBox(height: 16),
          Text(
            message,
            style: const TextStyle(color: Colors.white70, fontSize: 16),
          ),
        ],
      ),
    );
  }
}
