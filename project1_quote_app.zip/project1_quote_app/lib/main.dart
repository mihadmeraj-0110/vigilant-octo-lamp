// ════════════════════════════════════════════════════════════
// FILE: main.dart
// ════════════════════════════════════════════════════════════
// WHAT YOU LEARN:
//  1. void main() — entry point of every Flutter app
//  2. BlocProvider — makes QuoteBloc available to all screens
//  3. MaterialApp — root widget, sets theme and home screen
//  4. ThemeData — app-wide styling
//  5. const MyApp() — const constructor, never rebuilds
// ════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'bloc/quote_bloc.dart';
import 'screen/quote_screen.dart';

void main() {
  // runApp — takes the root widget and starts the app
  runApp(const MyApp());
}

// MyApp — StatelessWidget because app config never changes
class MyApp extends StatelessWidget {
  // PUBLIC key via super.key — Flutter uses this to track widget
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // BlocProvider — creates QuoteBloc and provides it to
    // all widgets in the tree below
    // Any child can access it via context.read<QuoteBloc>()
    return BlocProvider(
      create: (_) => QuoteBloc()
        // Immediately fetch a quote when app starts
        // ..add() = cascade operator, calls add() on the BLoC
        // and still returns the BLoC instance
        ..add(const QuoteFetchRequested()),

      child: MaterialApp(
        title: 'Quote App',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: Colors.deepPurple,
          ),
          useMaterial3: true,
        ),
        home: const QuoteScreen(),
      ),
    );
  }
}
