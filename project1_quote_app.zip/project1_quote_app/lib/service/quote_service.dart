// ════════════════════════════════════════════════════════════
// FILE: service/quote_service.dart
// ════════════════════════════════════════════════════════════
// WHAT YOU LEARN:
//  1. Service class — one job only: talk to the API
//  2. PRIVATE Dio instance (_dio) — only this class uses it
//  3. async/await — fetch data without blocking UI
//  4. DioException — handle network errors properly
//  5. Parsing List response — API returns a List, not a Map
//  6. Repository pattern — BLoC calls service, never Dio directly
// ════════════════════════════════════════════════════════════

import 'package:dio/dio.dart';
import '../model/quote_model.dart';

class QuoteService {
  // PRIVATE Dio instance — configured once, reused for all calls
  // BaseOptions sets defaults for every request this Dio makes
  final Dio _dio = Dio(
    BaseOptions(
      baseUrl:        'https://zenquotes.io/api',
      connectTimeout: const Duration(seconds: 5),
      receiveTimeout: const Duration(seconds: 5),
    ),
  );

  // fetchRandomQuote — returns a single Quote
  // 'async' = this function is asynchronous, returns Future<Quote>
  // 'await' = pause here until Dio gets a response (non-blocking)
  Future<Quote> fetchRandomQuote() async {
    try {
      // GET /random — returns a JSON array with one quote object
      final response = await _dio.get('/random');

      // response.data is dynamic — could be anything
      // We know the API returns a List, so cast it
      final List<dynamic> data = response.data as List<dynamic>;

      // data[0] — first item in the list
      // Cast to Map<String, dynamic> — that's what fromJson expects
      final Quote quote = Quote.fromJson(
        data[0] as Map<String, dynamic>,
      );

      return quote;

    } on DioException catch (e) {
      // DioException — network-specific errors
      // We convert to a plain Exception with a readable message
      throw Exception(_handleDioError(e));
    } catch (e) {
      // Any other unexpected error
      throw Exception('Unexpected error: $e');
    }
  }

  // PRIVATE helper — maps DioException type to a message
  // Keeps the catch block clean and readable
  String _handleDioError(DioException e) {
    switch (e.type) {
      case DioExceptionType.connectionTimeout:
        return 'Connection timed out. Check your internet.';
      case DioExceptionType.receiveTimeout:
        return 'Server is taking too long. Try again.';
      case DioExceptionType.connectionError:
        return 'No internet connection.';
      case DioExceptionType.badResponse:
        return 'Server error: ${e.response?.statusCode}';
      default:
        return 'Network error: ${e.message}';
    }
  }
}
